<?php
include 'backend/connection.php';
session_start();
$usermail = $_SESSION['getmail'];
if (!isset($_SESSION['getmail'])) {
    header('location:index.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <title>Document</title>
    <?php
    include 'customerlinks.php';
    ?>
</head>
<body>
<body class="vertical  light  ">
<div class="wrapper">
    <?php
    include 'customerheader.php';
    ?>
    <main role="main" class="main-content">
            <div class="container-fluid">
                <div class="row justify-content-center">
                    
                </div>
            </div>
    </main>
</div>
<?php 
include 'customerfooter.php'
?>
</body>
</body>
</html>