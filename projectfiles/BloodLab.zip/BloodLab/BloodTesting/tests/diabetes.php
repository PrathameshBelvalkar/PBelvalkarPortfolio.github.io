<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=\, initial-scale=1.0">
    <title>Document</title>
    <?php
    require '../links.php';
    ?>
</head>
<body>
<body class="vertical  light  ">
<div class="wrapper">
    <?php
    require '../header.php';
    ?>
</div>
<?php 
require '../footer.php'
?>
</body>
</body>
</html>